package Weapons;

public class SuperWeapon {

	public String name;
	public int damage;
	
}
