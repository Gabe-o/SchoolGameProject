package Weapons;

public class Weapon_Shotgun extends SuperWeapon{

	public Weapon_Shotgun() {
		name = "Shotgun";
		damage = 25;
	}
}
