package Weapons;

public class Weapon_Sniper extends SuperWeapon {

	public Weapon_Sniper() {
		name = "Sniper";
		damage = 50;
	}
}
