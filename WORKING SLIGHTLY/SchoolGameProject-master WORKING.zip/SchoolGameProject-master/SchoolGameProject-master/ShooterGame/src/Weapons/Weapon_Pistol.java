package Weapons;

public class Weapon_Pistol extends SuperWeapon{

	public Weapon_Pistol () {
		name = "Pistol";
		damage = 25;
	}
}
